package zelda;

public enum Orientation {
    SOUTH,
    WEST,
    EAST, 
    NORTH
}
