package zelda.enemies;

public class mage extends ennemies{

	@Override
	public void fight() {
		int indice=(int) (1 + (Math.random() * (8 - 1)));
		String [] dir= {"N","S","E","O", "NE", "NO", "SE", "SO"};
		
		
	}

}
