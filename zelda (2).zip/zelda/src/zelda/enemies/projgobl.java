package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;

import zelda.Orientation;

public class projgobl extends projsimple{

	public projgobl(Game game, Orientation orientation, double x, double y) {
		super(game, orientation, x, y);
	}

	@Override
	public void initResources(double x, double y) {
		 BufferedImage[] sprites = new BufferedImage[4];
	        sprites[0] = game.getImage("res/sprites/Objects/OWAE");
	        sprites[1] = game.getImage("res/sprites/Objects/OWAW");
	        sprites[2] = game.getImage("res/sprites/Objects/OWAN");
	        sprites[3] = game.getImage("res/sprites/Objects/OWAS");
	        this.setImages(sprites);
	        this.setLocation(x, y);
	        this.setAnimationFrame(0, 0);
		
	}

	@Override
	public void shoot(Orientation direction) {
    	switch(direction) {
    	case NORTH: 
    		this.setAnimationFrame(2, 2);
    		this.setAnimate(true);
    		this.setVerticalSpeed(-projsimple.SPEED);
    		this.setHorizontalSpeed(0);
    		break;
    	case SOUTH:
    		this.setAnimationFrame(3, 3);
    		this.setAnimate(true);
            this.setVerticalSpeed(projsimple.SPEED);
            this.setHorizontalSpeed(0);
            break;
    	case EAST:
    		this.setAnimationFrame(0, 0);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(projsimple.SPEED);
            break;
    	case WEST:
    		this.setAnimationFrame(1, 1);
    		this.setAnimate(true);
            this.setVerticalSpeed(0);
            this.setHorizontalSpeed(-projsimple.SPEED);
            break;
    	}
    }
}
