package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Timer;

import zelda.Orientation;
import zelda.enemies.ennemies.EnnemiesCollisionManager;
import zelda.scenary.Quest;

public class goblin extends ennemies{
	
	protected projgobl projectile;
	
	public goblin(Game game) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(ennemies.ANIMATION_DELAY);
        this.figth = new Timer(ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.orientation=orientation.SOUTH;
        this.manager = new EnnemiesCollisionManager();
        this.initResources();
    }
	
	
	private void initResources() {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = getGame().getImage("res/sprites/Ennemies/goblingauche1.png");
        sprites[1] = getGame().getImage("res/sprites/Ennemies/goblingauche2.png");
        sprites[2] = getGame().getImage("res/sprites/Ennemies/goblindroite1.png");
        sprites[3] = getGame().getImage("res/sprites/Ennemies/goblindroite2.png");
        sprites[4] = getGame().getImage("res/sprites/Ennemies/goblinbas1.png");
        sprites[5] = getGame().getImage("res/sprites/Ennemies/goblinbas2.png");
        sprites[6] = getGame().getImage("res/sprites/Ennemies/goblinhaut1.png");
        sprites[7] = getGame().getImage("res/sprites/Ennemies/goblinhaut2.png");
        this.setImages(sprites);
        this.setLocation(300, 380);
        this.setAnimationFrame(0, 0);
    }

	@Override
	public void fight() {
		int indice=(int) (1 + (Math.random() * (4 - 1)));
		Orientation [] dir= {Orientation.SOUTH, Orientation.NORTH, Orientation.WEST, Orientation.EAST};
		Orientation or=dir[indice];
		this.projectile= new projgobl(this.game, or, this.getX(),this.getY());
		projectile.shoot(or);
		
	}

}
