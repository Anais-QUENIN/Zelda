package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Timer;

import zelda.Orientation;
import zelda.enemies.ennemies.EnnemiesCollisionManager;

public class octo extends ennemies{

	protected projoct projectile;
	
	public octo(Game game) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(ennemies.ANIMATION_DELAY);
        this.figth = new Timer(ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.orientation=orientation.SOUTH;
        this.manager = new EnnemiesCollisionManager();
        this.initResources();
    }
	
	
	private void initResources() {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = getGame().getImage("res/sprites/Ennemies/octogauchecourt.png");
        sprites[1] = getGame().getImage("res/sprites/Ennemies/octogauchelong.png");
        sprites[2] = getGame().getImage("res/sprites/Ennemies/octodroitecourt.png");
        sprites[3] = getGame().getImage("res/sprites/Ennemies/octodroitelong.png");
        sprites[4] = getGame().getImage("res/sprites/Ennemies/octobascourt.png");
        sprites[5] = getGame().getImage("res/sprites/Ennemies/octobaslong.png");
        sprites[6] = getGame().getImage("res/sprites/Ennemies/octohautcourt.png");
        sprites[7] = getGame().getImage("res/sprites/Ennemies/octohautlong.png");
        this.setImages(sprites);
        this.setLocation(300, 380);
        this.setAnimationFrame(4, 4);
    }
	
	@Override
	public void fight() {
		int indice=(int) (1 + (Math.random() * (4 - 1)));
		Orientation [] dir= {Orientation.SOUTH, Orientation.NORTH, Orientation.WEST, Orientation.EAST};
		Orientation or=dir[indice];
		this.projectile= new projoct (this.game, or, this.getX(),this.getY());
		projectile.shoot(or);
		
	}

}
