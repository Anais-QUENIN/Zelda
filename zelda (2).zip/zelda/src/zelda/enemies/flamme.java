package zelda.enemies;

import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.object.Timer;

import zelda.Orientation;
import zelda.enemies.ennemies.EnnemiesCollisionManager;

public class flamme extends ennemies{
	
	public flamme(Game game) {
        this.setGame(game);
        this.getAnimationTimer().setDelay(ennemies.ANIMATION_DELAY);
        this.figth = new Timer(ennemies.FIGHT_TIMER);
        this.figth.setActive(false);
        this.orientation=orientation.SOUTH;
        this.manager = new EnnemiesCollisionManager();
        this.initResources();
    }
	
	
	private void initResources() {
        BufferedImage[] sprites = new BufferedImage[8];
        sprites[0] = getGame().getImage("res/sprites/Ennemies/flamme1.png");
        sprites[1] = getGame().getImage("res/sprites/Ennemies/flamme2.png");
        sprites[2] = getGame().getImage("res/sprites/Ennemies/flamme1.png");
        sprites[3] = getGame().getImage("res/sprites/Ennemies/flamme2.png");
        sprites[4] = getGame().getImage("res/sprites/Ennemies/flamme1.png");
        sprites[5] = getGame().getImage("res/sprites/Ennemies/flamme2.png");
        sprites[6] = getGame().getImage("res/sprites/Ennemies/flamme1.png");
        sprites[7] = getGame().getImage("res/sprites/Ennemies/flamme2.png");
        this.setImages(sprites);
        this.setLocation(300, 380);
        this.setAnimationFrame(0, 0);
    }

	@Override
	public void fight() {
		// TODO Auto-generated method stub
		
	}
	
	public void bas_droite() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(this.SPEED);
            this.setVerticalSpeed(this.SPEED);
            this.orientation = Orientation.SOUTH_EAST;
		}
	}
	
	public void bas_gauche() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(-this.SPEED);
            this.setVerticalSpeed(this.SPEED);
            this.orientation = Orientation.SOUTH_WEST;
		}
	}
	
	public void haut_droite() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(this.SPEED);
            this.setVerticalSpeed(-this.SPEED);
            this.orientation = Orientation.NORTH_EAST;
		}
	}
	
	public void haut_gauche() {
		if (!this.figth.isActive()) {
			this.setAnimationFrame(4, 5);
			this.setAnimate(true);
            this.setHorizontalSpeed(-this.SPEED);
            this.setVerticalSpeed(-this.SPEED);
            this.orientation = Orientation.NORTH_WEST;
		}
	}

}
